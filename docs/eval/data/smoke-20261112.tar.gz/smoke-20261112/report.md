# Model-upgrade eval report — batch-2026-11-12T01-39-27-724Z

Generated from `smoke-20261112` by tools/eval/report.ts. Every number below is recomputable from that directory.

## 1. What ran

| field | value |
|---|---|
| batch_id | batch-2026-11-12T01-39-27-724Z |
| git commit | a7786b4cc568a4aaca9fa35c9a2eb1fa410f12ae (dirty tree) on claude/new-session-egbz8q |
| created | 2026-11-12T01:39:38.065Z |
| finished | 2026-11-12T01:43:24.863Z |
| execution mode | local-multi-backend |
| concurrency | 5 arms in flight per (PR, rep); each backend runs 2 orchestrators (swarm + basic), each with a pool of 5 concurrent Gemini calls. all arms review the same PR/rep simultaneously; retries run under lighter load (recorded per attempt) |
| PRs | 1 (0 small, 1 large ≥10 changed files) |
| excluded PRs | none |
| repetitions | 1 |
| seed | 20261112 |
| max attempts per run | 3 |
| attempt timeout | 900s |
| review-call cap | 10 |

| arm | role | discovery | remediation | basic | deduplicate | evaluate | thinking level | max output | caching |
|---|---|---|---|---|---|---|---|---|---|
| BASE | baseline | gemini-3.1-pro-preview | gemini-3.1-pro-preview | gemini-3.1-pro-preview | gemini-3.1-pro-preview | gemini-3.1-pro-preview | default (none sent) | 32768 | false |
| BASE2 | control | gemini-3.1-pro-preview | gemini-3.1-pro-preview | gemini-3.1-pro-preview | gemini-3.1-pro-preview | gemini-3.1-pro-preview | default (none sent) | 32768 | false |
| ARGON | candidate | gemini-4-argon | gemini-4-argon | gemini-4-argon | gemini-4-argon | gemini-4-argon | default (none sent) | 32768 | false |
| FLASH38 | candidate | gemini-3.8-flash | gemini-3.8-flash | gemini-3.8-flash | gemini-3.8-flash | gemini-3.8-flash | default (none sent) | 32768 | false |
| FLASH38_LOW | candidate | gemini-3.8-flash | gemini-3.8-flash | gemini-3.8-flash | gemini-3.8-flash | gemini-3.8-flash | LOW | 32768 | false |

Routing above is what each server reported on `/api/status` before any review ran (checked against the resolver; a mismatch aborts the batch).

## 2. Integrity

### Reliability (one HTTP review per run; both modes share it)

| arm | runs | first attempt complete | first attempt clean (no stage flag) | retries | never completed | attempt outcomes (all attempts) |
|---|---|---|---|---|---|---|
| BASE | 1 | 1/1 (100%) | 1/1 (100%) | 0 | 0 | success:1 |
| BASE2 | 1 | 1/1 (100%) | 1/1 (100%) | 0 | 0 | success:1 |
| ARGON | 1 | 1/1 (100%) | 1/1 (100%) | 0 | 0 | success:1 |
| FLASH38 | 1 | 1/1 (100%) | 1/1 (100%) | 0 | 0 | success:1 |
| FLASH38_LOW | 1 | 1/1 (100%) | 1/1 (100%) | 0 | 0 | success:1 |

"Complete" = a `done` frame with >0 calls. Only an incomplete attempt is retried; a complete attempt with stage flags (MAX_TOKENS, parse failure, stage timeout, served-model mismatch) is **kept**, flagged, and counted in the tables below — retrying those would select for luck.

### Per-stage calls and flags (accepted results only; shared = the evaluate call, counted under both modes)

| arm | mode | stage | calls | MAX_TOKENS | timeouts | parse failures | served-model mismatches | thinking tokens |
|---|---|---|---|---|---|---|---|---|
| BASE | basic | discovery | 1 | 0 | 0 | 0 | 0 | 22403 |
| BASE | basic | remediation | 1 | 0 | 0 | 0 | 0 | 3827 |
| BASE | basic | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 0 |
| BASE | swarm | discovery | 7 | 0 | 0 | 0 | 0 | 49661 |
| BASE | swarm | remediation | 4 | 0 | 0 | 0 | 0 | 22033 |
| BASE | swarm | deduplicate | 1 | 0 | 0 | 0 | 0 | 0 |
| BASE | swarm | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 0 |
| BASE2 | basic | discovery | 1 | 0 | 0 | 0 | 0 | 20609 |
| BASE2 | basic | remediation | 1 | 0 | 0 | 0 | 0 | 6482 |
| BASE2 | basic | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 0 |
| BASE2 | swarm | discovery | 7 | 0 | 0 | 0 | 0 | 33964 |
| BASE2 | swarm | remediation | 4 | 0 | 0 | 0 | 0 | 18969 |
| BASE2 | swarm | deduplicate | 1 | 0 | 0 | 0 | 0 | 0 |
| BASE2 | swarm | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 0 |
| ARGON | basic | discovery | 1 | 0 | 0 | 0 | 0 | 1933 |
| ARGON | basic | remediation | 1 | 0 | 0 | 0 | 0 | 17 |
| ARGON | basic | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 0 |
| ARGON | swarm | discovery | 7 | 0 | 0 | 0 | 0 | 2604 |
| ARGON | swarm | remediation | 5 | 0 | 0 | 0 | 0 | 1126 |
| ARGON | swarm | deduplicate | 1 | 0 | 0 | 0 | 0 | 559 |
| ARGON | swarm | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 0 |
| FLASH38 | basic | discovery | 1 | 0 | 0 | 0 | 0 | 0 |
| FLASH38 | basic | remediation | 1 | 0 | 0 | 0 | 0 | 5803 |
| FLASH38 | basic | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 1182 |
| FLASH38 | swarm | discovery | 7 | 0 | 0 | 0 | 0 | 34974 |
| FLASH38 | swarm | remediation | 3 | 0 | 0 | 0 | 0 | 2602 |
| FLASH38 | swarm | deduplicate | 1 | 0 | 0 | 0 | 0 | 8183 |
| FLASH38 | swarm | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 1182 |
| FLASH38_LOW | basic | discovery | 1 | 0 | 0 | 0 | 0 | 0 |
| FLASH38_LOW | basic | remediation | 1 | 0 | 0 | 0 | 0 | 0 |
| FLASH38_LOW | basic | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 965 |
| FLASH38_LOW | swarm | discovery | 7 | 0 | 0 | 0 | 0 | 781 |
| FLASH38_LOW | swarm | remediation | 3 | 0 | 0 | 0 | 0 | 0 |
| FLASH38_LOW | swarm | deduplicate | 1 | 0 | 0 | 0 | 0 | 244 |
| FLASH38_LOW | swarm | shared.evaluate | 1 | 0 | 0 | 0 | 0 | 965 |

## 3. Findings: volume and hallucination (per arm × mode × size class)

Hallucinated = does not survive `validateFindingsAgainstDiff` (file/line not in the PR diff). Basic and swarm findings are reported separately: basic findings never go through the deduplicator.

| arm | mode | size | runs | findings/run | valid/run | valid HIGH+/run | hallucinated |
|---|---|---|---|---|---|---|---|
| BASE | basic | all | 1 | 3.0 | 2.0 | 1.0 | 1/3 (33%) |
| BASE | basic | large | 1 | 3.0 | 2.0 | 1.0 | 1/3 (33%) |
| BASE | swarm | all | 1 | 11.0 | 11.0 | 3.0 | 0/11 (0%) |
| BASE | swarm | large | 1 | 11.0 | 11.0 | 3.0 | 0/11 (0%) |
| BASE2 | basic | all | 1 | 2.0 | 1.0 | 1.0 | 1/2 (50%) |
| BASE2 | basic | large | 1 | 2.0 | 1.0 | 1.0 | 1/2 (50%) |
| BASE2 | swarm | all | 1 | 16.0 | 12.0 | 2.0 | 4/16 (25%) |
| BASE2 | swarm | large | 1 | 16.0 | 12.0 | 2.0 | 4/16 (25%) |
| ARGON | basic | all | 1 | 3.0 | 3.0 | 1.0 | 0/3 (0%) |
| ARGON | basic | large | 1 | 3.0 | 3.0 | 1.0 | 0/3 (0%) |
| ARGON | swarm | all | 1 | 20.0 | 20.0 | 1.0 | 0/20 (0%) |
| ARGON | swarm | large | 1 | 20.0 | 20.0 | 1.0 | 0/20 (0%) |
| FLASH38 | basic | all | 1 | 2.0 | 2.0 | 1.0 | 0/2 (0%) |
| FLASH38 | basic | large | 1 | 2.0 | 2.0 | 1.0 | 0/2 (0%) |
| FLASH38 | swarm | all | 1 | 3.0 | 3.0 | 1.0 | 0/3 (0%) |
| FLASH38 | swarm | large | 1 | 3.0 | 3.0 | 1.0 | 0/3 (0%) |
| FLASH38_LOW | basic | all | 1 | 1.0 | 1.0 | 1.0 | 0/1 (0%) |
| FLASH38_LOW | basic | large | 1 | 1.0 | 1.0 | 1.0 | 0/1 (0%) |
| FLASH38_LOW | swarm | all | 1 | 2.0 | 2.0 | 0.0 | 0/2 (0%) |
| FLASH38_LOW | swarm | large | 1 | 2.0 | 2.0 | 0.0 | 0/2 (0%) |

## 4. Recall against BASE, both directions (secondary measure)

`recall of BASE` = share of BASE's valid findings (same PR, same repetition) that this arm also reports within ±10 lines (greedy 1:1). `BASE recall of arm` = share of this arm's valid findings BASE also reports. It rewards whichever model writes more; ground truth (§5) is the precision/recall measure that matters. BASE2 is the A/A noise floor.

| arm | mode | size | runs | recall of BASE | BASE recall of arm |
|---|---|---|---|---|---|
| BASE2 | basic | all | 1 | 0% | 0% |
| BASE2 | basic | large | 1 | 0% | 0% |
| BASE2 | swarm | all | 1 | 64% | 58% |
| BASE2 | swarm | large | 1 | 64% | 58% |
| ARGON | basic | all | 1 | 50% | 33% |
| ARGON | basic | large | 1 | 50% | 33% |
| ARGON | swarm | all | 1 | 45% | 25% |
| ARGON | swarm | large | 1 | 45% | 25% |
| FLASH38 | basic | all | 1 | 0% | 0% |
| FLASH38 | basic | large | 1 | 0% | 0% |
| FLASH38 | swarm | all | 1 | 27% | 100% |
| FLASH38 | swarm | large | 1 | 27% | 100% |
| FLASH38_LOW | basic | all | 1 | 0% | 0% |
| FLASH38_LOW | basic | large | 1 | 0% | 0% |
| FLASH38_LOW | swarm | all | 1 | 9% | 50% |
| FLASH38_LOW | swarm | large | 1 | 9% | 50% |

## 5. Ground truth

**UNMEASURED.** None of the ground-truth PRs (the 10 seeded `gemini-cli-fork` PRs, the `job_tracker` audit PRs) were part of this batch.

Seeded-bug PRs in this batch: 0/10. Not in the batch: 10. Known limitation: every seeded diff has an `// INTENTIONAL DEFECT` comment beside the bug, so catching it is easy; a miss is informative, a hit proves little.

## 6. LLM-judge verdicts (only verdicts BOTH judges agree on)

| arm vs BASE | mode | judged pairs | agreed wins | agreed losses | agreed ties | judges disagree | invalid/missing |
|---|---|---|---|---|---|---|---|
| ARGON | basic | 1 | 0 | 0 | 0 | 1 | 0 |
| ARGON | swarm | 1 | 1 | 0 | 0 | 0 | 0 |
| FLASH38 | basic | 1 | 0 | 0 | 0 | 1 | 0 |
| FLASH38 | swarm | 1 | 1 | 0 | 0 | 0 | 0 |
| FLASH38_LOW | basic | 1 | 0 | 0 | 0 | 1 | 0 |
| FLASH38_LOW | swarm | 1 | 1 | 0 | 0 | 0 | 0 |
| BASE2 | basic | 1 | 0 | 0 | 0 | 1 | 0 |
| BASE2 | swarm | 1 | 0 | 0 | 0 | 1 | 0 |

Judges used: 1:gemini-2.5-pro, 2:gemini-3.8-flash, 2:gemini-4-argon. Judge order is randomized per call and un-swapped before scoring. A record whose judge was served by a different model than requested is invalid.

## 7. Latency, thinking tokens and cost

All arms in this batch ran in one execution mode (local-multi-backend) at the same concurrency (5 arms in flight per PR/rep), so they are comparable with each other. They are **not** comparable with latency or cost from any other batch, execution mode, or concurrency level. Latency uses only runs accepted on the first attempt (retries run under different load).

| arm | accepted runs | first-attempt runs | review wall-clock p50 | p95 | thinking tokens/review | cost/review today | cost/review from 2026-12-01 (Argon $4/$20) | cost/review from 2027-01-01 (3.8 Flash $1.50/$7.50) | if thinking billed on top |
|---|---|---|---|---|---|---|---|---|---|
| BASE | 1 | 1 | 226s | 226s | 97924 | $0.430 | $0.430 | $0.430 | +$1.175 |
| BASE2 | 1 | 1 | 226s | 226s | 80024 | $0.443 | $0.443 | $0.443 | +$0.960 |
| ARGON | 1 | 1 | 151s | 151s | 6239 | $0.632 | $1.265 | $1.265 | +$0.062 |
| FLASH38 | 1 | 1 | 211s | 211s | 52744 | $0.150 | $0.150 | $0.301 | +$0.198 |
| FLASH38_LOW | 1 | 1 | 33s | 33s | 1990 | $0.136 | $0.136 | $0.272 | +$0.007 |

Costs use recorded input/output tokens per stage × the PRICE_TABLE rate for that stage's requested model at the stated date (`gemini-4-argon` rows are **unverified**, see TODO.md #46). Thinking tokens are not added to cost (same convention as `usage.ts`); the last column is the upper bound if they are billed on top of output tokens. Cached tokens are zero here (caching is off on every arm).

| arm | mode | runs | orchestrator wall-clock p50 | p95 | thinking tokens/run |
|---|---|---|---|---|---|
| BASE | basic | 1 | 165s | 165s | 26230 |
| BASE | swarm | 1 | 226s | 226s | 71694 |
| BASE2 | basic | 1 | 175s | 175s | 27091 |
| BASE2 | swarm | 1 | 226s | 226s | 52933 |
| ARGON | basic | 1 | 53s | 53s | 1950 |
| ARGON | swarm | 1 | 151s | 151s | 4289 |
| FLASH38 | basic | 1 | 62s | 62s | 6985 |
| FLASH38 | swarm | 1 | 211s | 211s | 46941 |
| FLASH38_LOW | basic | 1 | 19s | 19s | 965 |
| FLASH38_LOW | swarm | 1 | 33s | 33s | 1990 |

## 8. Statistics: each candidate vs BASE, per PR

The unit is the PR (repetitions averaged within a PR first). Columns: PRs used; mean BASE; mean candidate; PRs where the candidate is lower/higher/equal; exact two-sided sign-test p; 95% bootstrap interval of the change (4000 resamples over PRs, fixed seed; % for counts, points for shares). FAIL = the whole interval is below -10. WARN = interval upper bound below 0 and sign p ≤ 0.10. **WARN is not a pass.** Fewer than 4 paired PRs: identical → PASS, otherwise UNMEASURED.

### ARGON vs BASE — basic

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.50 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 2.00 | 3.00 | 0/1/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | all | 1 | 1.00 | 0.50 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 2.00 | 3.00 | 0/1/0 | 1.000 | n/a | UNMEASURED |

### ARGON vs BASE — swarm

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.45 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 11.00 | 20.00 | 0/1/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | all | 1 | 1.00 | 0.45 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 11.00 | 20.00 | 0/1/0 | 1.000 | n/a | UNMEASURED |

### FLASH38 vs BASE — basic

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 2.00 | 2.00 | 0/0/1 | 1.000 | n/a | PASS |
| recall of BASE findings | all | 1 | 1.00 | 0.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 2.00 | 2.00 | 0/0/1 | 1.000 | n/a | PASS |

### FLASH38 vs BASE — swarm

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.27 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 11.00 | 3.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | all | 1 | 1.00 | 0.27 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 11.00 | 3.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |

### FLASH38_LOW vs BASE — basic

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 2.00 | 1.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | all | 1 | 1.00 | 0.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 2.00 | 1.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |

### FLASH38_LOW vs BASE — swarm

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.09 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 11.00 | 2.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | all | 1 | 1.00 | 0.09 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 11.00 | 2.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |

### BASE2 vs BASE — basic (A/A control: expected to show NO difference)

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 2.00 | 1.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | all | 1 | 1.00 | 0.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 2.00 | 1.00 | 1/0/0 | 1.000 | n/a | UNMEASURED |

### BASE2 vs BASE — swarm (A/A control: expected to show NO difference)

| measure | size | PRs | mean BASE | mean arm | lower/higher/equal | sign p | 95% interval of change | verdict |
|---|---|---|---|---|---|---|---|---|
| seeded-bug catch rate | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| must_catch (job_tracker audit) | all | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | large | 1 | 1.00 | 0.64 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | all | 1 | 11.00 | 12.00 | 0/1/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | all | 1 | 1.00 | 0.64 | 1/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| recall of BASE findings | small | 0 | n/a | n/a | 0/0/0 | 1.000 | n/a | UNMEASURED |
| valid findings | large | 1 | 11.00 | 12.00 | 0/1/0 | 1.000 | n/a | UNMEASURED |

## 9. Gates and decision (pre-registered in docs/eval/model-upgrade-test-plan.md)

### ARGON — basic: **UNDETERMINED**

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | ARGON 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: ARGON [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: ARGON [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

Ground truth: UNMEASURED; large-PR recall: UNMEASURED. - gate unmeasured: ground truth: no FAIL - gate unmeasured: must_not_flag_high: false alarms <= BASE - ground truth: UNMEASURED - large-PR recall: UNMEASURED

### ARGON — swarm: **UNDETERMINED**

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | ARGON 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: ARGON [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: ARGON [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

Ground truth: UNMEASURED; large-PR recall: UNMEASURED. - gate unmeasured: ground truth: no FAIL - gate unmeasured: must_not_flag_high: false alarms <= BASE - ground truth: UNMEASURED - large-PR recall: UNMEASURED

### FLASH38 — basic: **UNDETERMINED**

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | FLASH38 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: FLASH38 [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: FLASH38 [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

Ground truth: UNMEASURED; large-PR recall: UNMEASURED. - gate unmeasured: ground truth: no FAIL - gate unmeasured: must_not_flag_high: false alarms <= BASE - ground truth: UNMEASURED - large-PR recall: UNMEASURED

### FLASH38 — swarm: **UNDETERMINED**

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | FLASH38 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: FLASH38 [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: FLASH38 [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

Ground truth: UNMEASURED; large-PR recall: UNMEASURED. - gate unmeasured: ground truth: no FAIL - gate unmeasured: must_not_flag_high: false alarms <= BASE - ground truth: UNMEASURED - large-PR recall: UNMEASURED

### FLASH38_LOW — basic: **UNDETERMINED**

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | FLASH38_LOW 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: FLASH38_LOW [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: FLASH38_LOW [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

Ground truth: UNMEASURED; large-PR recall: UNMEASURED. - gate unmeasured: ground truth: no FAIL - gate unmeasured: must_not_flag_high: false alarms <= BASE - ground truth: UNMEASURED - large-PR recall: UNMEASURED

### FLASH38_LOW — swarm: **UNDETERMINED**

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | FLASH38_LOW 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: FLASH38_LOW [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: FLASH38_LOW [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

Ground truth: UNMEASURED; large-PR recall: UNMEASURED. - gate unmeasured: ground truth: no FAIL - gate unmeasured: must_not_flag_high: false alarms <= BASE - ground truth: UNMEASURED - large-PR recall: UNMEASURED

### BASE2 (A/A control) — basic

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | BASE2 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: BASE2 [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: BASE2 [discovery=0, remediation=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

### BASE2 (A/A control) — swarm

| gate | status | detail |
|---|---|---|
| served-model mismatches = 0 | PASS | 0 mismatched call(s) over 1 run(s) [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| first-attempt success >= BASE - \|BASE-BASE2\| | PASS | BASE2 100% vs floor 100% (BASE 100%, BASE2 100%, gap 0 pts) |
| MAX_TOKENS + timeouts per stage <= BASE | PASS | MAX_TOKENS+timeouts: BASE2 [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| parse failures per stage <= BASE | PASS | parse failures: BASE2 [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] vs BASE [discovery=0, remediation=0, deduplicate=0, shared.evaluate=0] |
| ground truth: no FAIL | UNMEASURED | seeded: UNMEASURED (only 0 paired PRs (< 4)); must_catch: UNMEASURED (only 0 paired PRs (< 4)) |
| must_not_flag_high: false alarms <= BASE | UNMEASURED | no must_not_flag_high entries were scored in this batch |

Cost and latency only break ties; they never outweigh a quality loss.
